# Data Loading Record - Load.py Execution (2025-12-02)

## Execution Summary
- **Timestamp**: 2025-12-02 21:57:47 - 2025-12-02 22:00:47
- **Duration**: ~3 minutes
- **Status**: ✓ SUCCESSFUL
- **Command Used**:
  ```bash
  python scripts/load.py \
    --data-path /Users/duonghongduc/GrinnellCollege/MLAI/Data/SEAAD_A9_RNAseq_DREAM_Cleaned.h5ad \
    --output-dir ./results \
    --n-hvgs 2000 \
    --min-label-ratio 0.25
  ```

---

## Data Output Locations

### Train/Val/Test Sets
| Dataset | Location | Size | Cells | Genes | Label 0 | Label 1 |
|---------|----------|------|-------|-------|---------|---------|
| **Train** | `results/processed/train.h5ad` | 127 MB | 59,894 | 2,000 | 15,164 (25.3%) | 44,730 (74.7%) |
| **Val** | `results/processed/val.h5ad` | 22 MB | 10,331 | 2,000 | 2,421 (23.4%) | 7,910 (76.6%) |
| **Test** | `results/processed/test.h5ad` | 36 MB | 16,558 | 2,000 | 6,860 (41.4%) | 9,698 (58.6%) |

### Full Paths
```
/Users/duonghongduc/GrinnellCollege/MLAI/__CODE/ADetective/results/processed/train.h5ad
/Users/duonghongduc/GrinnellCollege/MLAI/__CODE/ADetective/results/processed/val.h5ad
/Users/duonghongduc/GrinnellCollege/MLAI/__CODE/ADetective/results/processed/test.h5ad
```

### Log File
```
/Users/duonghongduc/GrinnellCollege/MLAI/__CODE/ADetective/results/load_fresh.log
```

---

## Data Loading Pipeline Steps

### Step 1: Load Raw Data
- **Source**: `/Users/duonghongduc/GrinnellCollege/MLAI/Data/SEAAD_A9_RNAseq_DREAM_Cleaned.h5ad`
- **Loading Mode**: Backed mode (memory-mapped) for efficient loading
- **Initial Shape**: 1,304,960 cells × 36,601 genes

### Step 2: Explore Metadata
- **Key metadata columns identified**: 30 columns including
  - Clinical: Sex, Age at Death, Cognitive Status, APOE Genotype
  - Pathology: ADNC, Braak, CERAD, LATE, Tau, Amyloid markers
  - Cell Type: Subclass (24 types), Supertype (131 types), Class (3 types)
  - Technical: library_prep (190 values), Method (2 values), PMI

### Step 3: Filter for Oligodendrocytes
- **Filter Column**: Subclass
- **Target Cell Type**: Oligodendrocyte cells
- **Cells After Filtering**: 142,059 (10.9% of total)

### Step 4: Filter Genes (min_cells=100)
- **Initial Genes**: 36,601
- **Final Genes**: 25,867 (29.3% removed)

### Step 5: Create Binary Labels
- **Label Source**: ADNC (Alzheimer Disease Neuropathologic Change)
- **Categories**: High (62,338) vs Not AD (24,445)
- **Total Labeled Cells**: 86,783

### Step 6: Check Preprocessing State
- **Log Transformation**: ✓ Yes
- **Normalization**: ✓ Yes
- **Data Type**: float32
- **Value Range**: 0.0 - 7.7971
- **Mean**: 0.1366, 99th percentile: 2.0595

### Step 7: Donor Distribution
- **Total Donors**: 48
- **Label 0 (Not AD) Donors**: 9
- **Label 1 (High AD) Donors**: 39
- **Distribution**: Imbalanced (9:39 ratio)

### Step 8: Create Train/Val/Test Splits
- **Strategy**: Donor-level stratified split to prevent data leakage
- **Split Ratios**: Train 70%, Val 15%, Test 15%
- **Stratification**: By label with weighted cell count distribution
- **Minimum Label Ratio**: 25%

**Stratification Key Distribution**:
- High AD, low cells: 12 donors
- High AD, medium cells: 13 donors
- High AD, high cells: 12 donors
- Not AD, low cells: 2 donors
- Not AD, medium cells: 3 donors
- Not AD, high cells: 4 donors

### Step 9: Normalize Data (After Split)
- **Method**: Normalize each split independently to prevent data leakage
- **Train**: Already normalized (CV=0.0947 < 0.1)
- **Val**: Applied library-size normalization (CV before: 0.1023)
- **Test**: Already normalized (CV=0.0978 < 0.1)

### Step 10: Select Highly Variable Genes (HVGs)
- **Selected**: 2,000 HVGs from training set
- **Method**: Computed on normalized training data
- **Applied To**: Val and test sets use identical 2,000 genes

### Step 11: Verify Final Preprocessing State
- **Final Shape**: 59,894 × 2,000 (train)
- **Log Transformation**: ✓ Yes
- **Normalization**: ✗ No (after gene selection)
- **Value Range**: 0.0 - 6.0882
- **Mean**: 0.1717, 99th percentile: 2.4135

### Step 12: Save Processed Data
- **Format**: AnnData H5AD
- **Saved Files**:
  - train.h5ad (127 MB)
  - val.h5ad (22 MB)
  - test.h5ad (36 MB)
- **Categorical Columns Stored**: label_name

---

## Label Distribution Summary

### Training Set
- **High**: 44,730 cells (74.7%)
- **Not AD**: 15,164 cells (25.3%)
- **Ratio Check**: ✓ PASS (min ratio 25.3% ≥ 25%)

### Validation Set
- **High**: 7,910 cells (76.6%)
- **Not AD**: 2,421 cells (23.4%)
- **Ratio Check**: ⚠️ WARNING (min ratio 23.4% < 25%)
  - *Note: Acceptable for validation but below target threshold*

### Test Set
- **High**: 9,698 cells (58.6%)
- **Not AD**: 6,860 cells (41.4%)
- **Ratio Check**: ✓ PASS (min ratio 41.4% ≥ 25%)

---

## Data Leakage Prevention Measures

1. ✓ **HVG Selection**: Computed only on training data, applied to val/test
2. ✓ **Normalization**: Applied separately to each split after splitting
3. ✓ **Stratification**: Donor-level split to avoid same donor in multiple splits
4. ✓ **Gene Filtering**: Applied to full dataset before splitting (acceptable)
5. ✓ **Preprocessing**: Already normalized and log-transformed in raw file

---

## Data Characteristics

### Cell Type Focus
- **Primary**: Oligodendrocyte cells (142,059 selected from 1.3M total)
- **Cell States**: 24 Subclasses captured

### Genetic Background
- **APOE Genotype**: 6 unique values (strong AD genetic predictor)
- **Cognitive Status**: 2 values (Dementia vs No dementia)

### Pathology Markers
- **ADNC**: 4 categories (classification target)
- **Braak**: 6 stages
- **CERAD**: 4 levels
- **Pathological Proteins**: Amyloid, Tau, GFAP, Alpha-Synuclein, pTDP43

### Gene Expression
- **Total genes in source**: 36,601
- **After min_cells filter**: 25,867
- **Selected as HVGs**: 2,000
- **Log-normalized**: Yes
- **Type**: RNA-seq data

---

## Donor Information

- **Total Donors**: 48
- **Donors per Split**:
  - Train: 32 donors
  - Val: 8 donors
  - Test: 8 donors

---

## Warnings and Notes

1. ⚠️ **Validation Set Imbalance**: Minority class ratio (23.4%) slightly below 25% threshold
   - Still acceptable for validation phase
   - Test set has better balance (41.4%)

2. ℹ️ **Data Preprocessing State**:
   - Data is log-transformed and normalized in source
   - After HVG selection, stored as log-transformed but not re-normalized
   - Ready for model input without additional preprocessing

3. ℹ️ **Memory Usage**:
   - Raw file loaded in backed (memory-mapped) mode
   - Only loaded subset into memory during splits
   - Total output size: 185 MB (train + val + test)

---

## Version Information

- **Load Script**: `scripts/load.py`
- **Data Format**: AnnData (.h5ad)
- **Python Version**: 3.13
- **Key Dependencies**: anndata, pandas, numpy, scanpy

---

## Quick Reference

```python
# Load the processed data
import anndata as ad

train = ad.read_h5ad('results/processed/train.h5ad')  # 59,894 × 2,000
val = ad.read_h5ad('results/processed/val.h5ad')      # 10,331 × 2,000
test = ad.read_h5ad('results/processed/test.h5ad')    # 16,558 × 2,000

# Access labels
print(train.obs['label_name'].value_counts())

# Access gene expression
print(train.X)  # (59894, 2000) matrix
```

---

**Generated**: 2025-12-02 22:00:47
**Status**: ✓ Data loading and preprocessing complete, ready for model training
